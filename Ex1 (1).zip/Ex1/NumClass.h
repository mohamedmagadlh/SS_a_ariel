#ifndef _MyLIB_H_
#define _MYLIB_H_

int isArmstrong(int x);
int isPalindrome(int x);
int isPrime(int x);
int isStrong(int x);


#endif